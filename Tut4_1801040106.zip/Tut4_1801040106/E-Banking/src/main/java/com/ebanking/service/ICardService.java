package com.ebanking.service;

import java.util.List;

import com.ebanking.model.Card;

public interface ICardService {
	public List<Card> findAll();
	public Card findCardById(int cardId);
}
