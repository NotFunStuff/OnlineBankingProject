package com.ebanking.service;

import java.util.List;

import com.ebanking.model.Bill;

public interface IBillService {
	List<Bill> findAll();
	Bill findBillById(int billId);
}
