package com.ebanking.controller.web;

import java.io.IOException;

import javax.inject.Inject;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ebanking.dao.IBillDAO;
import com.ebanking.service.IAccountService;
import com.ebanking.service.IBillService;
import com.ebanking.service.ICardService;


@WebServlet(urlPatterns = { "/home", "/log-in" })
public class HomeController extends HttpServlet {

	@Inject
	private IAccountService accountService;
	
	@Inject
	private ICardService cardService;
	
	@Inject
	private IBillService billService;
	
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		request.setAttribute("account", accountService.findById(1));
		request.setAttribute("card", cardService.findCardById(1));
		request.setAttribute("bill", billService.findBillById(1));
		RequestDispatcher rd = request.getRequestDispatcher("/views/web/Home.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
