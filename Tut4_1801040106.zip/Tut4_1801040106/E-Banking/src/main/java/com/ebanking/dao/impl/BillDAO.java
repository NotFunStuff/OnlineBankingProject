package com.ebanking.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ebanking.dao.IBillDAO;
import com.ebanking.model.Bill;
import com.ebanking.model.Card;

public class BillDAO extends NewDAO implements IBillDAO{

	@Override
	public List<Bill> findAll() {
		List<Bill> bills = new ArrayList<Bill>();
		String sql = "SELECT * FROM ebanking.card;";
		Connection connection = getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		if(connection != null)
		{
			try {
				statement = connection.prepareStatement(sql);
				resultSet = statement.executeQuery();
				while (resultSet.next())
				{
					Bill bill = new Bill();
					bill.setBillId(resultSet.getInt("billId"));
					bill.setDesription(resultSet.getNString("description"));
					bill.setReceiveAccountId(resultSet.getInt("receiveAccountId"));
					bill.setAccountId(resultSet.getInt("accountId"));
					bill.setTimeCreated(resultSet.getTimestamp("timeCreated"));
					bill.setTransferMoney(resultSet.getInt("transferMoney"));
					bills.add(bill);
				}
				return bills;
			} catch (SQLException e) {
				e.printStackTrace();
				return null;
			}finally {
				try {
					if(connection != null)
					{
						connection.close();
					}
					if(statement != null)
					{
						statement.close();
					}
					if(resultSet != null)
					{
						resultSet.close();
					}
				}catch (SQLException e) {
					return null;
				}
				
			}
		}
		return null;
	}

	@Override
	public Bill findBillById(int billId) {
		Bill bill = new Bill();
		String sql = "SELECT * FROM ebanking.bill where billId = ?;";
		Connection connection = getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		if(connection != null)
		{
			try {
				statement = connection.prepareStatement(sql);
				statement.setInt(1, billId);
				resultSet = statement.executeQuery();
				while (resultSet.next())
				{
					
					bill.setBillId(resultSet.getInt("billId"));
					bill.setDesription(resultSet.getNString("description"));
					bill.setReceiveAccountId(resultSet.getInt("receiveAccountId"));
					bill.setAccountId(resultSet.getInt("accountId"));
					bill.setTimeCreated(resultSet.getTimestamp("timeCreated"));
					bill.setTransferMoney(resultSet.getInt("transferMoney"));
					
				}
				return bill;
			} catch (SQLException e) {
				e.printStackTrace();
				return null;
			}finally {
				try {
					if(connection != null)
					{
						connection.close();
					}
					if(statement != null)
					{
						statement.close();
					}
					if(resultSet != null)
					{
						resultSet.close();
					}
				}catch (SQLException e) {
					return null;
				}
				
			}
		}
		return null;
	}

}
