package com.ebanking.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ebanking.dao.ICardDAO;
import com.ebanking.model.Card;

public class CardDAO extends NewDAO implements ICardDAO{

	@Override
	public List<Card> findAll() {
		List<Card> cards = new ArrayList<Card>();
		String sql = "SELECT * FROM ebanking.card;";
		Connection connection = getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		if(connection != null)
		{
			try {
				statement = connection.prepareStatement(sql);
				resultSet = statement.executeQuery();
				while (resultSet.next())
				{
					Card card = new Card();
					card.setCardId(resultSet.getInt("cardId"));
					card.setCardNumber(resultSet.getString("cardNumber"));
					card.setCurrentMoney(resultSet.getInt("currentMoney"));
					card.setTimeCreated(resultSet.getTimestamp("timeCreated"));
					cards.add(card);
				}
				return cards;
			} catch (SQLException e) {
				e.printStackTrace();
				return null;
			}finally {
				try {
					if(connection != null)
					{
						connection.close();
					}
					if(statement != null)
					{
						statement.close();
					}
					if(resultSet != null)
					{
						resultSet.close();
					}
				}catch (SQLException e) {
					return null;
				}
				
			}
		}
		return null;
	}

	@Override
	public Card findCardById(int cardId) {
		Card card = new Card();
		String sql = "SELECT * FROM ebanking.card where cardId = ?;";
		Connection connection = getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		if(connection != null)
		{
			try {
				statement = connection.prepareStatement(sql);
				statement.setInt(1, cardId);
				resultSet = statement.executeQuery();
				while (resultSet.next())
				{
					
					card.setCardId(resultSet.getInt("cardId"));
					card.setCardNumber(resultSet.getString("cardNumber"));
					card.setCurrentMoney(resultSet.getInt("currentMoney"));
					card.setTimeCreated(resultSet.getTimestamp("timeCreated"));
					
				}
				return card;
			} catch (SQLException e) {
				e.printStackTrace();
				return null;
			}finally {
				try {
					if(connection != null)
					{
						connection.close();
					}
					if(statement != null)
					{
						statement.close();
					}
					if(resultSet != null)
					{
						resultSet.close();
					}
				}catch (SQLException e) {
					return null;
				}
				
			}
		}
		return null;
	}
	
}
