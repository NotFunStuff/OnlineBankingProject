package com.ebanking.dao;

import java.sql.Connection;

public interface INewDAO {
	public Connection getConnection() ;
		
}
