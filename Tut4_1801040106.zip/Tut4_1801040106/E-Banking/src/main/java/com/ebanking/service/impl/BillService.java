package com.ebanking.service.impl;

import java.util.List;

import javax.inject.Inject;

import com.ebanking.dao.IBillDAO;
import com.ebanking.model.Bill;
import com.ebanking.service.IBillService;

public class BillService implements IBillService{

	@Inject
	private IBillDAO billDao;
	
	@Override
	public List<Bill> findAll() {
		
		return billDao.findAll();
	}

	@Override
	public Bill findBillById(int billId) {
		
		return billDao.findBillById(billId);
	}
	
}
