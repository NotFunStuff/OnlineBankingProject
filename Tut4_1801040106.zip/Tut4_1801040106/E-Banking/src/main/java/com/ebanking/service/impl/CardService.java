package com.ebanking.service.impl;

import java.util.List;

import javax.inject.Inject;

import com.ebanking.dao.ICardDAO;
import com.ebanking.model.Card;
import com.ebanking.service.ICardService;

public class CardService implements ICardService {

	@Inject
	ICardDAO cardDao;
	
	@Override
	public List<Card> findAll() {
		
		return cardDao.findAll();
	}

	@Override
	public Card findCardById(int cardId) {
		
		return cardDao.findCardById(cardId);
	}

}
