package com.ebanking.service.impl;

import com.ebanking.service.INewService;

public class NewService implements INewService {

}
