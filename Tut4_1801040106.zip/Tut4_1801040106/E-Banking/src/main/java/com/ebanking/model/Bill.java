package com.ebanking.model;

import java.sql.Timestamp;

public class Bill {
	private int billId;
	private Timestamp timeCreated;
	private Account account;
	private int accountId;
	private int transferMoney;
	private Account receiveAccount;
	private int receiveAccountId;
	private String desription;
	public int getBillId() {
		return billId;
	}
	public void setBillId(int billId) {
		this.billId = billId;
	}
	public Timestamp getTimeCreated() {
		return timeCreated;
	}
	public void setTimeCreated(Timestamp timeCreated) {
		this.timeCreated = timeCreated;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getTransferMoney() {
		return transferMoney;
	}
	public void setTransferMoney(int transferMoney) {
		this.transferMoney = transferMoney;
	}
	
	public String getDesription() {
		return desription;
	}
	public void setDesription(String desription) {
		this.desription = desription;
	}
	public Account getReceiveAccount() {
		return receiveAccount;
	}
	public void setReceiveAccount(Account receiveAccount) {
		this.receiveAccount = receiveAccount;
	}
	public int getReceiveAccountId() {
		return receiveAccountId;
	}
	public void setReceiveAccountId(int receiveAccountId) {
		this.receiveAccountId = receiveAccountId;
	}
	
	
	
	
}
