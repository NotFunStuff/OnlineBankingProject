package com.ebanking.service;

public interface INewService {

}
