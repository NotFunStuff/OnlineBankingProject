package com.ebanking.dao;

import java.util.List;

import com.ebanking.model.Bill;

public interface IBillDAO {
	List<Bill> findAll();
	Bill findBillById(int billId);
}
