package com.ebanking.dao;

import java.util.List;

import com.ebanking.model.Card;

public interface ICardDAO {
	public List<Card> findAll();
	public Card findCardById(int cardId);
}
